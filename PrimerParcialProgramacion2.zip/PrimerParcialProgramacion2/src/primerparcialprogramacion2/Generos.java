
package primerparcialprogramacion2;

public enum Generos {
    FICCION,
   NO_FICCION, 
   CIENCIA,
   HISTORIA
    
}
