package primerparcialprogramacion2;

public interface Lejibles {
    
    public abstract void leer();    
    
}
