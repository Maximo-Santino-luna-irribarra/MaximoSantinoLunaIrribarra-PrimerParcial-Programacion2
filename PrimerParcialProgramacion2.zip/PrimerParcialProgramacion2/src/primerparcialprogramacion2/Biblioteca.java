package primerparcialprogramacion2;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    protected List<Publicacion> publicaciones;

    public Biblioteca() {
        publicaciones = new ArrayList<>();
    }

    public List<Publicacion> getPublicaciones() {
        return publicaciones;
    }

    public void agregarPublicacion(Publicacion publicacion) {
    
        publicaciones.add(publicacion);
    }

    public void mostrarPublicaciones() {
        for (Publicacion publicacion : publicaciones) {
            System.out.println(publicacion);
        }
    }

    public void leerPublicaciones() {
        for (Publicacion publi : publicaciones) {
            if (publi instanceof Lejibles) {
                ((Lejibles) publi).leer();
            } else {
                System.out.println("No se puede leer: " + publi.getTitulo());
            }
        }
    }
}