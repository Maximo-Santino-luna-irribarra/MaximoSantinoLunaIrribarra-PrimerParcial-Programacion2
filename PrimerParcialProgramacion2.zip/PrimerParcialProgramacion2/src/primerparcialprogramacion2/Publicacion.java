
package primerparcialprogramacion2;

import java.util.Objects;

public abstract class Publicacion {
    protected String Titulo;
    protected int Año;

    public Publicacion(String Titulo, int Año) {
        this.Titulo = Titulo;
        this.Año = Año;
    }
    public String getTitulo() {
        return Titulo;
    }
    public int getAño() {
        return Año;
    }

   
    @Override
    public  String toString() {
        return "Publicacion{" + "Titulo = " + Titulo +"del año =  "+ Año + '}';
    }
    
    
    
    
}
