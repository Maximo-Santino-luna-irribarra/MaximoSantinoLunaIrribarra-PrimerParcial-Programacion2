package primerparcialprogramacion2;

public class Main {
    public static void main(String[] args) {
        
        Biblioteca biblio = new Biblioteca();
        biblio.agregarPublicacion(new Revistas(5, "don armando", 2020));
        biblio.agregarPublicacion(new ilustraciones("pintura rara", 40, 60, "amor", 1889));
        biblio.agregarPublicacion(new Libros("juan", Generos.FICCION, "the 100", 1967));
        biblio.agregarPublicacion(new Libros("alberto", Generos.CIENCIA, "y fin ", 1988));
       
        
        System.out.println("publicaciones:");
        biblio.mostrarPublicaciones();
        System.out.println("publicaciones:");
        biblio.leerPublicaciones();
    }
}