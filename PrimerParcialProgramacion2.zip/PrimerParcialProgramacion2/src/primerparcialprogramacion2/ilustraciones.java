package primerparcialprogramacion2;


class ilustraciones extends Publicacion {
    private String nombreIlustrador;
    private int Alto;
    private int Ancho;

    public ilustraciones(String nombreIlustrador, int Alto, int Ancho, String Titulo, int Año) {
        super(Titulo, Año);
        this.nombreIlustrador = nombreIlustrador;
        this.Alto = Alto;
        this.Ancho = Ancho;
    }

    public String getNombreIlustrador() {
        return nombreIlustrador;
    }

    public int getAlto() {
        return Alto;
    }

    public int getAncho() {
        return Ancho;
    }

    @Override
    public String toString() {
        return "ilustraciones{" + "el nombreIlustrador es " + nombreIlustrador + ", tiene de Alto =" + Alto + ",tiene de  Ancho =" + Ancho + '}';
    }
    

    
    
    
}
