package primerparcialprogramacion2;


class Libros extends Publicacion  implements Lejibles{
    private String Autor;
    private Generos Genero;

    public Libros(String Autor, Generos Genero, String Titulo, int Año) {
        super(Titulo, Año);
        this.Autor = Autor;
        this.Genero = Genero;
    }

    
    public String getAutor() {
        return Autor;
    }

    public Generos getGenero() {
        return Genero;
    }

    
    @Override
    public void leer() {
        System.out.println("se puede leer el libro:" + getTitulo()+"del autor" + getAutor());
        
    }
    
}
