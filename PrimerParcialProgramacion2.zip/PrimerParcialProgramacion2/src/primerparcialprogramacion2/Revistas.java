
package primerparcialprogramacion2;

class Revistas extends Publicacion implements Lejibles {
    private int numeroDeEdicion;

    public Revistas(int numeroDeEdicion, String Titulo, int Año) {
        super(Titulo, Año);
        this.numeroDeEdicion = numeroDeEdicion;
    }

    public int getNumeroDeEdicion() {
        return numeroDeEdicion;
    }
    
    @Override
    public void leer() {
        System.out.println("se esta leyendo la revista "+ getTitulo() +" edicion" + getNumeroDeEdicion() );
         
    }
    
}
//